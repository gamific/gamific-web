var teste = document.createElement("div");

var chart_config = {
  "chart": {
    "container": "#custom-colored",
    "nodeAlign": "BOTTOM",
    "connectors": {
      "type": "step"
    },
    "node": {
      "HTMLclass": "nodeExample1"
    }
  },
  "nodeStructure": {
    "text": {
      "name": "Rebel-9"
    },
    "image": "https://s3.amazonaws.com/gamific-prd/images/logos/empresas/logo-40",
    "children": [
      {
        "children": null,
        "text": {
          "name": "Rebel-2"
        },
        "image": "https://s3.amazonaws.com/gamific-prd/images/logos/empresas/logo-40",
        "HTMLclass": "light-gray"
      },
      {
        "children": null,
        "text": {
          "name": "Rebel-8"
        },
        "image": "https://s3.amazonaws.com/gamific-prd/images/logos/empresas/logo-40",
        "HTMLclass": "light-gray"
      },
      {
        "children": null,
        "text": {
          "name": "Rebel-6"
        },
        "image": "https://s3.amazonaws.com/gamific-prd/images/logos/empresas/logo-40",
        "HTMLclass": "light-gray"
      },
      {
        "children": null,
        "text": {
          "name": "Rebel-5"
        },
        "image": "https://s3.amazonaws.com/gamific-prd/images/logos/empresas/logo-40",
        "HTMLclass": "light-gray"
      },
      {
        "children": null,
        "text": {
          "name": "Rebel-4"
        },
        "image": "https://s3.amazonaws.com/gamific-prd/images/logos/empresas/logo-40",
        "HTMLclass": "light-gray"
      },
      {
        "children": null,
        "text": {
          "name": "Rebel-3"
        },
        "image": "https://s3.amazonaws.com/gamific-prd/images/logos/empresas/logo-40",
        "HTMLclass": "light-gray"
      },
      {
        "children": null,
        "text": {
          "name": "Rebel-1"
        },
        "image": "https://s3.amazonaws.com/gamific-prd/images/logos/empresas/logo-40",
        "HTMLclass": "light-gray"
      },
      {
        "children": null,
        "text": {
          "name": "Rebel-0"
        },
        "image": "https://s3.amazonaws.com/gamific-prd/images/logos/empresas/logo-40",
        "HTMLclass": "light-gray"
      },
      {
        "children": null,
        "text": {
          "name": "Rebel-7"
        },
        "image": "https://s3.amazonaws.com/gamific-prd/images/logos/empresas/logo-40",
        "HTMLclass": "light-gray"
      }
    ]
  }
}